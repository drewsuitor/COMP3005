Problem1 contains all of the .sql scripts for the telephone switch database, as well as the database.

Problem2 contains the merged database, fakebooks3005winter2016.db. The 'songs' table is the updated table.

Problem3_3 contains the web app for searching and modifying songs and bookcodes. Navigate into the 'API_with_updates' folder and type 'npm install' and then 'npm start'